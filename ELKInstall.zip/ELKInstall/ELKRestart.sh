#!/bin/bash
echo "Restarting ELK processes"
sudo systemctl restart elasticsearch || exit 1
sudo systemctl restart kibana || exit 1
sudo systemctl restart metricbeat || exit 1
sudo systemctl restart filebeat || exit 1
sudo systemctl restart heartbeat-elastic || exit 1
sleep 60s
echo "Restart complete"
echo "Keep your head held high! Have a good one!"
exit 0
