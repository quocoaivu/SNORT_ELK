#!/bin/bash
#Prerequisites
function prereq {
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Welcome to Dan's ELK Linux Install Script"
	echo "We will need a tad bit of user input during installation phase so don't go away!"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Prerequisite Install Phase"
	echo "You will need to input Enter when prompted"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	read -n 1 -s -r -p "Press any key to continue"
	echo ""
	echo "Starting..."
	sleep 5
	clear
	sudo add-apt-repository ppa:webupd8team/java || exit 1
	sudo apt update || exit 1
	sleep 5
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "You will be prompted to agree to Java's License Agreement"
	echo "Select <OK> at first screen"
	echo "Select <Yes> at second screen"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 10s
	clear
	sudo apt install -y oracle-java8-installer oracle-java8-set-default || exit 1
	sudo apt install -y curl apt-transport-https || exit 1
	#javav = $(`javac -version`)
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Please make sure the java version installed is 8 or higher"
	echo "Current Java Version installed"
	echo `javac -version`
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 10s
	elastic
}
#
#Now we install Elasticsearch
function elastic {
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Beginning Elasticsearch Install Phase"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Don't forget to edit the configuration to your topology"
	echo "Configuration file is /etc/elasticsearch/elasticsearch.yml"
	echo "Please wait as we prepare to install Elasticsearch"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 10s

	wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add - || exit 1
	sudo echo "deb https://artifacts.elastic.co/packages/6.x/apt stable main" | sudo tee –a /etc/apt/sources.list.d/elastic-6.x.list || exit 1
		sudo apt update || exit 1
		sleep 5s
	sudo apt install elasticsearch || exit 1
	#Start it up
	sudo systemctl enable elasticsearch || exit 1
	sudo systemctl restart elasticsearch || exit 1
	#Test
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Elasticsearch has been installed"
	echo "Please wait while we start up Elasticsearch"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 60
	clear
	curl http://localhost:9200
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "The output above should NOT display 'connection refused'"
	echo "If the connection is refused the installation was not a success"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	testing
}

function testing {
	read -p "Was the above command successful? [Y/N]: " curltest
	case $curltest in
		Y|y)
			echo "Great! Moving on to Logstash soon!"
			sleep 5
			logstash
			;;
		N|n)
			echo "Dang, let's try reinstalling prerequisites and restarting the services."
			sleep 5
			prereq
			;;
		*)
			echo "Invalid Input"
			echo "Try again"
			testing
			;;
	esac
}

#Now we install Logstash
function logstash {
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Begininng Logstash Install Phase"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Logstash will not work properly without proper configuration"
	echo "We will download and install but Logstash will not be started"
	echo "Please configure /etc/logstash/logstash.yml"
	echo "Please make .conf files in /etc/logstash/conf.d/"
	echo "Please wait as we prepare to install Logstash"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 15s
	sudo apt install logstash || exit 1
	#Auto start it
	sudo systemctl enable logstash || exit 1
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Logstash has been installed"
	echo "Logstash will start on boot"
	echo "Manually start Logstash when you have created the config files"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Moving on to Kibana soon!"
	sleep 15s
	kibana
}

#Now we install Kibana
function kibana {
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Beginning Kibana Install Phase"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Don't forget to edit the configuration to your topology"
	echo "Configuration file is /etc/kibana/kibana.yml"
	echo "Please wait as we prepare to install Kibana"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 10s
	sudo apt install kibana || exit 1
	#Start it up
	sudo systemctl enable kibana
	sudo systemctl restart kibana
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Kibana has been installed"
	echo "Please wait while we start up kibana"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 30s
	echo "Kibana has been started!"
	echo "Go to localhost:5601 on your favourite internet browser to check it out!"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Moving on to Beats soon!"
	sleep 10s
	beats
}

#Now we install Beats
function beats {
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Beginning Beats Install Phase"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Don't forget to edit the configurations to your topology"
	echo "Configuration file is /etc/metricbeat/metricbeat.yml"
	echo "Configuration file is /etc/filebeat/filebeat.yml"
	echo "Configuration file is /etc/heartbeat/hearbeat.yml"
	echo "Please wait as we prepare to install the Beats"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 5s
	sudo apt install metricbeat filebeat heartbeat-elastic || exit 1
	#Drop the beat
	sudo systemctl enable metricbeat
	sudo systemctl restart metricbeat
	sudo systemctl enable filebeat
	sudo systemctl restart filebeat
	sudo systemctl enable heartbeat-elastic
	sudo systemctl restart heartbeat-elastic
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Beats have been installed"
	echo "Please wait while we start them up"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 30s
	echo "Beats have been started!"
	echo "They will need configuration to connect to Logstash instead of Elasticsearch"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	sleep 10s
	ending
}

function ending {
	clear
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Installation Complete!"
	echo "ELK has been installed and is now running"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	echo "Don't forget to configure the seperate applications to fit your topology"
	echo "These are the apps and their config locations:"
	echo "Elasticsearch				/etc/elasticsearch/elasticsearch.yml"
	echo "Logstash				/etc/logstash/logstash.yml"
	echo "Kibana					/etc/kibana/kibana.yml"
	echo "metricbeat				/etc/metricbeat/metricbeat.yml"
	echo "filebeat				/etc/filebeat/filebeat.yml"
	echo "Hearbeat-Elastic			/etc/heartbeat/heartbeat.yml"
	echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
	read -n 1 -s -r -p "Enjoy the rest of your day!"
	echo " "
	exit 0
}

prereq